#!/usr/bin/env python
import rospy
import math
from psuedo.msg import numlist

def calculate_median(llist):
    listrnd = sorted(llist)
    listlen = len(llist)
    if listlen %2 == 0:
        med_a = listrnd[listlen//2]   #Since list indexing in Python starts with 0, floor of division result is used here
        #print(med_a)
        med_b = listrnd[(listlen//2)-1]
        #print(med_b)
        median = (med_a+med_b)/2.0      #2.0 is used to preserve float format of division
    else:
        median = listrnd[listlen//2]

    return median


def calculate_standard_deviation(listrnd):          #Result can vary little as there are variations in formulae itself for calculating deviation
    llength = len(listrnd)
    sum = 0.0
    for i in listrnd:
        sum =sum+i

    mean = sum//llength

    #print(mean)

    std_deviation = 0.0
    sqr_mean = 0.0
    for i in listrnd:
        sqr_mean = sqr_mean+((i-mean)**2)

    #print(sqr_mean)

    sqr_mean = sqr_mean//llength
    #print(sqr_mean)

    std_deviation = math.sqrt(sqr_mean)
        #print(sqr_mean)
    return std_deviation


def callback(randomlist):
    a=[]
    a=randomlist.numlist
    median = calculate_median(a)
    std_deviation = calculate_standard_deviation(a)
    print('median = ', median)
    print('standard deviation = ', std_deviation)


def listen_to_prn():
    rospy.init_node('listen_prn', anonymous=True)
    rospy.Subscriber("pseudo_random", numlist, callback)
    rospy.spin()


if __name__ == '__main__':
    listen_to_prn()
