#!/usr/bin/env python
import rospy
from random import seed
from random import randint
from psuedo.msg import numlist


def generate_prn():
    pub = rospy.Publisher("pseudo_random", numlist, queue_size=10)
    rospy.init_node('prng', anonymous=True)
    rate = rospy.Rate(0.5)
    randlist = []
    while not rospy.is_shutdown():
        seed(a=None)               # Seed will take system time as input
        for _ in range(12):        #Range can be changed to get desired number of random numbers
            value = randint(0,100)
            randlist.append(value)


        rospy.loginfo(randlist)
        pub.publish(randlist)
        randlist=[]
        rate.sleep()


if __name__ == '__main__':
    try:
        generate_prn()
    except rospy.ROSInterruptException:
        pass

