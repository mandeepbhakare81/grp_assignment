
"use strict";

let numlist = require('./numlist.js');

module.exports = {
  numlist: numlist,
};
